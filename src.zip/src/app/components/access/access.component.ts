import { Component, OnInit } from '@angular/core';
import { Login } from 'src/app/models/login';

@Component({
  selector: 'app-access',
  templateUrl: './access.component.html',
  styleUrls: ['./access.component.css']
})
export class AccessComponent implements OnInit {

  public objLogin: Login;

  constructor() {
    this.objLogin = new Login(0, '', '');
   }

  ngOnInit(): void {
  }

}
