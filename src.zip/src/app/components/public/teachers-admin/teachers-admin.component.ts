import { Teacher } from './../../../models/teacher';
import { ARRAY_TEACHERS } from './../../../mocks/teacher-mock';

import { ArrayPipe } from './../../../pipes/array.pipe';
import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-teachers-admin',
  templateUrl: './teachers-admin.component.html',
  styleUrls: ['./teachers-admin.component.css'],
  providers: [ArrayPipe],
})
export class TeachersAdminComponent implements OnInit {

  public arrayTeachers: Array<Teacher>;
  public currentPage: number;
  public quantityShow: number;
  public quantityPages: number;
  public quantityTotalRegisters: number;
  public teacherSelected : Teacher;
  public modalRef: BsModalRef;
  public modalTitle: string;
  public modalText: string;
  public modalContent: string;
  public objTeacher: Teacher;

  constructor(private modalService: BsModalService, private toastr: ToastrService,
              private sort: ArrayPipe, private router: Router) {
    const parameters = ['id', 'DES'];
    this.arrayTeachers = this.sort.transform(ARRAY_TEACHERS, parameters);
    this.currentPage = 1;
    this.quantityShow = 5;
    this.quantityPages = Math.ceil(this.arrayTeachers.length / this.quantityShow);
    this.quantityTotalRegisters = this.arrayTeachers.length;
    this.teacherSelected = new Teacher(0, '', '', '', '');
    this.modalRef = new BsModalRef;
    this.modalTitle = '';
    this.modalText = '';
    this.modalContent = '';
    this.objTeacher = new Teacher(0, '', '', '', '');
   }

  ngOnInit(): void {
  }

  public openModalDelete(template: TemplateRef<any>, tmpTeacher: Teacher): void {
    this.teacherSelected = tmpTeacher;
    this.modalRef = this.modalService.show(template, {class:'modal-md'});
    this.modalTitle = 'Warning';
    this.modalText = 'Do you really want to delete the teacher field?';
    this.modalContent = this.teacherSelected.teacherName;
  }

  public deleteTeacher(objTeacher: Teacher): void {
    this.arrayTeachers = this.arrayTeachers.filter(element => element != objTeacher);
    this.teacherSelected = new Teacher(0, '', '', '', '');
    this.toastr.success('Congratulations, the fields have been deleted successfully. ', 'SUCCESS');
    this.quantityTotalRegisters = this.quantityTotalRegisters - 1;
    if (this.quantityTotalRegisters % this.quantityShow == 0) {
      this.currentPage = 1;
      this.quantityPages = this.quantityPages - 1;
    }
  }

  public btnDelete(): void {
    this.deleteTeacher(this.teacherSelected);
    this.modalRef.hide();
  }

  public btnCancel(): void {
    this.modalRef.hide();
  }
}

