import { ARRAY_TEACHERS_UNIVERSITIES } from './../../../mocks/teacher-university-mock';
import { TeacherUniversity } from './../../../models/teacher-university';
import { ARRAY_TEACHERS } from 'src/app/mocks/teacher-mock';
import { Teacher } from 'src/app/models/teacher';

import { ArrayPipe } from './../../../pipes/array.pipe';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teachers-list',
  templateUrl: './teachers-list.component.html',
  styleUrls: ['./teachers-list.component.css'],
  providers: [ArrayPipe],
})
export class TeachersListComponent implements OnInit {

  public arrayTeachers: Array<Teacher>;
  public currentPage: number;
  public quantityShow: number;
  public quantityPages: number;
  public quantityTotalRegisters: number;
  public arrayTeachersUniversities: Array<TeacherUniversity>;

  constructor(private sort: ArrayPipe) {
    const parameters = ['id', 'DES'];
    this.arrayTeachers = this.sort.transform(ARRAY_TEACHERS, parameters);
    this.currentPage = 1;
    this.quantityShow = 5;
    this.quantityPages = Math.ceil(this.arrayTeachers.length / this.quantityShow);
    this.quantityTotalRegisters = this.arrayTeachers.length;
    this.arrayTeachersUniversities = ARRAY_TEACHERS_UNIVERSITIES;
   }

  ngOnInit(): void {
  }

}
