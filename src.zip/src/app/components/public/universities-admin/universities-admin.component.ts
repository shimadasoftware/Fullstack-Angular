import { ArrayPipe } from './../../../pipes/array.pipe';
import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { University } from 'src/app/models/university';
import { ARRAY_UNIVERSITIES } from 'src/app/mocks/university-mock';

@Component({
  selector: 'app-universities-admin',
  templateUrl: './universities-admin.component.html',
  styleUrls: ['./universities-admin.component.css'],
  providers: [ArrayPipe]
})
export class UniversitiesAdminComponent implements OnInit {

  public arrayUniversities: Array<University>;
  public currentPage: number;
  public quantityShow: number;
  public quantityPages: number;
  public quantityTotalRegisters: number;
  public universitySelected : University;
  public objUniversity: University;
  public modalRef: BsModalRef;
  public modalTitle: string;
  public modalText: string;
  public modalContent: string;

  constructor(private modalService: BsModalService, private toastr: ToastrService,
              private sort: ArrayPipe, private router: Router) {
    const parameters = ['id', 'DES'];
    this.arrayUniversities = this.sort.transform(ARRAY_UNIVERSITIES, parameters);
    this.currentPage = 1;
    this.quantityShow = 5;
    this.quantityPages = Math.ceil(this.arrayUniversities.length / this.quantityShow);
    this.quantityTotalRegisters = this.arrayUniversities.length;
    this.universitySelected = new University(0, '', '', '');
    this.modalRef = new BsModalRef;
    this.modalTitle = '';
    this.modalText = '';
    this.modalContent = '';
    this.objUniversity = new University(0, '', '', '');
  }

  ngOnInit(): void {
  }

  public openModalDelete(template: TemplateRef<any>, tmpTeacher: University): void {
    this.universitySelected = tmpTeacher;
    this.modalRef = this.modalService.show(template, {class:'modal-md'});
    this.modalTitle = 'Warning';
    this.modalText = 'Do you really want to delete the University field?';
    this.modalContent = this.universitySelected.universityName;
  }

  public deleteTeacher(objUniversity: University): void {
    this.arrayUniversities = this.arrayUniversities.filter(element => element != objUniversity);
    this.universitySelected = new University(0, '', '', '');
    this.toastr.success('Congratulations, the fields have been deleted successfully. ', 'SUCCESS');
    this.quantityTotalRegisters = this.quantityTotalRegisters - 1;
    if (this.quantityTotalRegisters % this.quantityShow == 0) {
      this.currentPage = 1;
      this.quantityPages = this.quantityPages - 1;
    }
  }

  public btnDelete(): void {
    this.deleteTeacher(this.universitySelected);
    this.modalRef.hide();
  }

  public btnCancel(): void {
    this.modalRef.hide();
  }
}
