import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-universities-principal',
  templateUrl: './universities-principal.component.html',
  styleUrls: ['./universities-principal.component.css']
})
export class UniversitiesPrincipalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
