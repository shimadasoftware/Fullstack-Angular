import { ARRAY_TEACHERS } from 'src/app/mocks/teacher-mock';
import { Teacher } from 'src/app/models/teacher';

import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';

@Component({
  selector: 'app-teachers-edit',
  templateUrl: './teachers-edit.component.html',
  styleUrls: ['./teachers-edit.component.css']
})
export class TeachersEditComponent implements OnInit {

  public tmpBase64: any;
  public objTeacher: Teacher;

  constructor(private toastr: ToastrService, private route: ActivatedRoute) {
    this.objTeacher = new Teacher(0,'', '', '', '');
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe((parameter: ParamMap) => {
      let tmpObject: any;
      const data = String(parameter.get('idTeacher'));
      const dataNumber = parseFloat(data);

      tmpObject = ARRAY_TEACHERS.find(
        (teacher) => teacher.id == dataNumber)
        this.objTeacher = tmpObject;
    });
  }

  public choosePicture(input: any):any {
    if (!input.target.files[0] || input.target.files[0].length === 0) {
      return;
    }
    const mimeType = input.target.files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      const parameters = {
        closeButton: true,
        enableHtml:true,
        progressBar:true,
        positionClass: 'toast-top-right',
        timeOut: 8000,
      };
      this.toastr.error('It is only enabled <strong>images<strong/>.', 'WARNING', parameters);
      return;
    }
    const reader = new FileReader();
    reader.readAsDataURL(input.target.files[0]);
    reader.onload = () => {
      this.tmpBase64 = reader.result;

      this.objTeacher.pictureBase64 = this.tmpBase64;
      this.objTeacher.picture = input.target.files[0].name;
    };
  }

  public sendInfo(form: NgForm): boolean {
    this.messageOK();
    return true;
  }

  public messageOK(): void {
    const parameters = {
      closeButton: true,
      enableHtml:true,
      progressBar:true,
      positionClass: 'toast-top-right',
      timeOut: 8000,
    };
    this.toastr.success('The teacher has been updated <strong>successfully<strong/>.', 'WARNING', parameters);
    return;
  }
}
