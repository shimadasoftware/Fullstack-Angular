import { ARRAY_TEACHERS } from 'src/app/mocks/teacher-mock';
import { TeacherUniversity } from './../../../models/teacher-university';
import { Teacher } from './../../../models/teacher';
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

import { University } from 'src/app/models/university';
import { ARRAY_UNIVERSITIES } from 'src/app/mocks/university-mock';
import { ARRAY_TEACHERS_UNIVERSITIES } from 'src/app/mocks/teacher-university-mock';

@Component({
  selector: 'app-universities-create',
  templateUrl: './universities-create.component.html',
  styleUrls: ['./universities-create.component.css']
})
export class UniversitiesCreateComponent implements OnInit {

  public tmpBase64: any;
  public objUniversity: University;
  public objTeacher: Teacher;
  public objTeacherUniversity: TeacherUniversity;
  public arrayTeachers: Array<Teacher>;
  public selectedTeachers = [];

  constructor(private toastr: ToastrService, private router: Router) {
    this.objUniversity = new University(0, '', '', '');
    this.objTeacher = new Teacher(0, '', '', '', '');
    this.objTeacherUniversity = new TeacherUniversity(
      new Teacher(0, '', '', '', ''),
      new University(0, '', '', '')
    );
    this.arrayTeachers = ARRAY_TEACHERS;
   }

  ngOnInit(): void {
  }

  public choosePicture(input: any):any {
    if (!input.target.files[0] || input.target.files[0].length === 0) {
      return;
    }
    const mimeType = input.target.files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      const parameters = {
        closeButton: true,
        enableHtml:true,
        progressBar:true,
        positionClass: 'toast-top-right',
        timeOut: 8000,
      };
      this.toastr.error('It is only enabled <strong>images<strong/>.', 'WARNING', parameters);
      return;
    }
    const reader = new FileReader();
    reader.readAsDataURL(input.target.files[0]);
    reader.onload = () => {
      this.tmpBase64 = reader.result;

      this.objUniversity.pictureBase64 = this.tmpBase64;
      this.objUniversity.picture = input.target.files[0].name;
    };
  }

  public sendInfo(form: NgForm): boolean {
    this.createUniversity();
    this.createTeacherUniversity(this.objUniversity);

    this.objTeacherUniversity = new TeacherUniversity(
      new Teacher(0, '', '', '', ''),
      new University(0, '', '', '')
    );

    this.objUniversity = new University(0, '', '', '');

    this.messageOK();
    this.router.navigate(['/universities/list']);
    return true;
  }

  public createUniversity(): void {
    this.objUniversity.id = ARRAY_UNIVERSITIES.length + 1;
    ARRAY_UNIVERSITIES.push(this.objUniversity);
  }

  public createTeacherUniversity(objUniversity: University): void {
    this.selectedTeachers.forEach(element => {
      for (let i = 0; i < ARRAY_TEACHERS.length; i++) {
        if (ARRAY_TEACHERS[i].id == element) {
          let teacherUniversity = new TeacherUniversity(
            ARRAY_TEACHERS[i],
            objUniversity
          );
          ARRAY_TEACHERS_UNIVERSITIES.push(teacherUniversity);
          break;
        }
      }
    });
  }

  public messageOK(): void {
    const parameters = {
      closeButton: true,
      enableHtml:true,
      progressBar:true,
      positionClass: 'toast-top-right',
      timeOut: 8000,
    };
    this.toastr.success('The University has been created <strong>successfully<strong/>.', 'SUCCESS', parameters);
    return;
  }
}

