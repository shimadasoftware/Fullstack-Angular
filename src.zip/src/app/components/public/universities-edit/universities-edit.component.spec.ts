import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UniversitiesEditComponent } from './universities-edit.component';

describe('UniversitiesEditComponent', () => {
  let component: UniversitiesEditComponent;
  let fixture: ComponentFixture<UniversitiesEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UniversitiesEditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UniversitiesEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
