import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';

import { University } from 'src/app/models/university';
import { ARRAY_UNIVERSITIES } from 'src/app/mocks/university-mock';

@Component({
  selector: 'app-universities-edit',
  templateUrl: './universities-edit.component.html',
  styleUrls: ['./universities-edit.component.css']
})
export class UniversitiesEditComponent implements OnInit {

  public tmpBase64: any;
  public objUniversity: University;

  constructor(private toastr: ToastrService, private route: ActivatedRoute) {
    this.objUniversity = new University(0,'', '', '');
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe((parameter: ParamMap) => {
      let tmpObject: any;
      const data = String(parameter.get('idUniversity'));
      const dataNumber = parseFloat(data);

      tmpObject = ARRAY_UNIVERSITIES.find(
        (university) => university.id == dataNumber)
        this.objUniversity = tmpObject;
    });
  }

  public choosePicture(input: any):any {
    if (!input.target.files[0] || input.target.files[0].length === 0) {
      return;
    }
    const mimeType = input.target.files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      const parameters = {
        closeButton: true,
        enableHtml:true,
        progressBar:true,
        positionClass: 'toast-top-right',
        timeOut: 8000,
      };
      this.toastr.error('It is only enabled <strong>images<strong/>.', 'WARNING', parameters);
      return;
    }
    const reader = new FileReader();
    reader.readAsDataURL(input.target.files[0]);
    reader.onload = () => {
      this.tmpBase64 = reader.result;

      this.objUniversity.pictureBase64 = this.tmpBase64;
      this.objUniversity.picture = input.target.files[0].name;
    };
  }

  public sendInfo(form: NgForm): boolean {
    this.messageOK();
    return true;
  }

  public messageOK(): void {
    const parameters = {
      closeButton: true,
      enableHtml:true,
      progressBar:true,
      positionClass: 'toast-top-right',
      timeOut: 8000,
    };
    this.toastr.success('The University has been updated <strong>successfully<strong/>.', 'WARNING', parameters);
    return;
  }

}
