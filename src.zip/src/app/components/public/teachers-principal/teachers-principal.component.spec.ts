import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeachersPrincipalComponent } from './teachers-principal.component';

describe('TeachersPrincipalComponent', () => {
  let component: TeachersPrincipalComponent;
  let fixture: ComponentFixture<TeachersPrincipalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TeachersPrincipalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TeachersPrincipalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
