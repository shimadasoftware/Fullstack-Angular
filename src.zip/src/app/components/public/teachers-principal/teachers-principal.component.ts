import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teachers-principal',
  templateUrl: './teachers-principal.component.html',
  styleUrls: ['./teachers-principal.component.css']
})
export class TeachersPrincipalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
