import { Component, OnInit } from '@angular/core';
import { ARRAY_UNIVERSITIES } from 'src/app/mocks/university-mock';
import { University } from 'src/app/models/university';
import { ArrayPipe } from './../../../pipes/array.pipe';

@Component({
  selector: 'app-universities-list',
  templateUrl: './universities-list.component.html',
  styleUrls: ['./universities-list.component.css'],
  providers: [ArrayPipe],
})
export class UniversitiesListComponent implements OnInit {

  public arrayUniversities: Array<University>;
  public currentPage: number;
  public quantityShow: number;
  public quantityPages: number;
  public quantityTotalRegisters: number;

  constructor(private sort: ArrayPipe) {
    const parameters = ['id', 'DES'];
    this.arrayUniversities = this.sort.transform(ARRAY_UNIVERSITIES, parameters);
    this.currentPage = 1;
    this.quantityShow = 5;
    this.quantityPages = Math.ceil(this.arrayUniversities.length / this.quantityShow);
    this.quantityTotalRegisters = this.arrayUniversities.length;
   }

  ngOnInit(): void {
  }

}
