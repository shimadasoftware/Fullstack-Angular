import { ARRAY_UNIVERSITIES } from 'src/app/mocks/university-mock';
import { ARRAY_TEACHERS_UNIVERSITIES } from './../../../mocks/teacher-university-mock';
import { ARRAY_TEACHERS } from 'src/app/mocks/teacher-mock';
import { TeacherUniversity } from './../../../models/teacher-university';
import { Teacher } from 'src/app/models/teacher';

import { Component, OnInit, Pipe } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { University } from 'src/app/models/university';
import { Observable, of } from 'rxjs';
import { delay, map } from 'rxjs/operators';

@Component({
  selector: 'app-teachers-create',
  templateUrl: './teachers-create.component.html',
  styleUrls: ['./teachers-create.component.css'],
})
export class TeachersCreateComponent implements OnInit {
  public tmpBase64: any;
  public objTeacher: Teacher;
  public objUniversity: University;
  public objTeacherUniversity: TeacherUniversity;
  public arrayTeachersUniversities: Array<TeacherUniversity>;
  public arrayUniversities: Array<University>;
  public selectedUniversities = [];

  constructor(private toastr: ToastrService, private router: Router) {
    this.objTeacher = new Teacher(0, '', '', '', '');
    this.objUniversity = new University(0, '', '', '');
    this.objTeacherUniversity = new TeacherUniversity(
      new Teacher(0, '', '', '', ''),
      new University(0, '', '', '')
    );
    this.arrayTeachersUniversities = ARRAY_TEACHERS_UNIVERSITIES;
    this.arrayUniversities = ARRAY_UNIVERSITIES;
  }

  ngOnInit(): void {
  }

  getUniversities(): Observable<any[]> {
    let u = [{}];
    ARRAY_UNIVERSITIES.forEach((element) => {
      u.push({
        key: element.id,
        value: element.universityName,
      });
    });
    return of(u);
  }

  public choosePicture(input: any): any {
    if (!input.target.files[0] || input.target.files[0].length === 0) {
      return;
    }
    const mimeType = input.target.files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      const parameters = {
        closeButton: true,
        enableHtml: true,
        progressBar: true,
        positionClass: 'toast-top-right',
        timeOut: 8000,
      };
      this.toastr.error(
        'It is only enabled <strong>images<strong/>.',
        'WARNING',
        parameters
      );
      return;
    }
    const reader = new FileReader();
    reader.readAsDataURL(input.target.files[0]);
    reader.onload = () => {
      this.tmpBase64 = reader.result;

      this.objTeacher.pictureBase64 = this.tmpBase64;
      this.objTeacher.picture = input.target.files[0].name;
    };
  }

  public sendInfo(form: NgForm): boolean {
    this.createTeacher();
    this.createTeacherUniversity(this.objTeacher);

    this.objTeacherUniversity = new TeacherUniversity(
      new Teacher(0, '', '', '', ''),
      new University(0, '', '', '')
    );

    this.objTeacher = new Teacher(0, '', '', '', '');

    this.messageOK();

    this.router.navigate(['/teachers/list']);

    return true;
  }

  public createTeacher(): void {
    this.objTeacher.id = ARRAY_TEACHERS.length + 1;
    ARRAY_TEACHERS.push(this.objTeacher);
    console.log(ARRAY_TEACHERS);
  }

  public createTeacherUniversity(objTeacher: Teacher): void {
    this.selectedUniversities.forEach(element => {
      for (let i = 0; i < ARRAY_UNIVERSITIES.length; i++) {
        if (ARRAY_UNIVERSITIES[i].id == element) {
          let teacherUniversity = new TeacherUniversity(
            objTeacher,
            ARRAY_UNIVERSITIES[i]
          );
          ARRAY_TEACHERS_UNIVERSITIES.push(teacherUniversity);
          break;
        }
      }
    });
  }
    /**
    this.selectedUniversities.forEach(element => {
      if (ARRAY_UNIVERSITIES.find(item => item.id === element)) {
        let objUniversity = ARRAY_UNIVERSITIES.find(item => item.id === element);
        let teacherUniversity = new TeacherUniversity(
          objTeacher,
          objUniversity
        );
        ARRAY_TEACHERS_UNIVERSITIES.push(this.objTeacherUniversity);
      }
      console.log('Juana' + element);
    });
    */


  /**
  public getUniversity(id: number): University {
    let university: University;
    university = ARRAY_UNIVERSITIES.find(item => item.id === id);
    if(university !== null) {
      return university;
    }
    else {
      return new University(0, '', '', '');
    }
     ARRAY_UNIVERSITIES.forEach(element => {
      if (id == element.id) {
        return element;
      }
    });
    return new University(0, '', '', '');
  }*/

  public messageOK(): void {
    const parameters = {
      closeButton: true,
      enableHtml: true,
      progressBar: true,
      positionClass: 'toast-top-right',
      timeOut: 8000,
    };
    this.toastr.success(
      'The teacher has been created <strong>successfully<strong/>.',
      'SUCCESS',
      parameters
    );
    return;
  }
}
