import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upper-menu',
  templateUrl: './upper-menu.component.html',
  styleUrls: ['./upper-menu.component.css']
})
export class UpperMenuComponent implements OnInit {

  public title: string;
  constructor() {
    this.title = 'Full Stack Angular'
   }

  ngOnInit(): void {
  }

}
