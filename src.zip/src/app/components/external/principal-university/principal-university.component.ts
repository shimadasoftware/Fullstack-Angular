import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-principal-university',
  templateUrl: './principal-university.component.html',
  styleUrls: ['./principal-university.component.css']
})
export class PrincipalUniversityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
