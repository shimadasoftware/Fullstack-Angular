import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrincipalUniversityComponent } from './principal-university.component';

describe('PrincipalUniversityComponent', () => {
  let component: PrincipalUniversityComponent;
  let fixture: ComponentFixture<PrincipalUniversityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrincipalUniversityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrincipalUniversityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
