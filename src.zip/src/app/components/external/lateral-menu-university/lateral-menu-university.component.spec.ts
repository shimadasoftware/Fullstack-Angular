import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LateralMenuUniversityComponent } from './lateral-menu-university.component';

describe('LateralMenuUniversityComponent', () => {
  let component: LateralMenuUniversityComponent;
  let fixture: ComponentFixture<LateralMenuUniversityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LateralMenuUniversityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LateralMenuUniversityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
