import { ArrayPipe } from './../../../pipes/array.pipe';
import { Component, OnInit } from '@angular/core';

import { University } from './../../../models/university';
import { ARRAY_UNIVERSITIES } from 'src/app/mocks/university-mock';

@Component({
  selector: 'app-lateral-menu-university',
  templateUrl: './lateral-menu-university.component.html',
  styleUrls: ['./lateral-menu-university.component.css'],
  providers: [ArrayPipe],
})
export class LateralMenuUniversityComponent implements OnInit {

  public arrayUniversities: Array<University>;
  public objUniversitiesSelected: University;

  constructor(private sort: ArrayPipe) {
    this.arrayUniversities = [];
    this.objUniversitiesSelected = new University(0, '', '', '');
  }

  ngOnInit(): void {
    const parameters = ['universityName', 'ASC'];
    this.arrayUniversities = this.sort.transform(ARRAY_UNIVERSITIES, parameters);
  }

  public selectUniversity(objuniversity: University): void {
    this.objUniversitiesSelected = objuniversity;
  }

  public initialize(): void {
    const parameters = ['universityName', 'ASC'];
    this.arrayUniversities = this.sort.transform(ARRAY_UNIVERSITIES, parameters);
    this.objUniversitiesSelected = new University(0, '', '', '');
  }

}
