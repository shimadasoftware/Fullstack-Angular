import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';

import { ARRAY_TEACHERS_UNIVERSITIES } from './../../../mocks/teacher-university-mock';
import { TeacherUniversity } from './../../../models/teacher-university';
import { Teacher } from 'src/app/models/teacher';
import { University } from 'src/app/models/university';


@Component({
  selector: 'app-detail-university',
  templateUrl: './detail-university.component.html',
  styleUrls: ['./detail-university.component.css']
})
export class DetailUniversityComponent implements OnInit {

  public arrayTeachersUniversities: Array<TeacherUniversity>;
  public quantityTeachers: number;
  public teacherUniversitySelected: TeacherUniversity;
  public tmp: any;

  constructor(private route: ActivatedRoute) {
    this.arrayTeachersUniversities = [];
    this.quantityTeachers = 0;
    this.teacherUniversitySelected = new TeacherUniversity (
      new Teacher(0, '', '', '', ''),
      new University(0, '', '', '')
    );
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe((param: ParamMap) => {
      this.tmp = param.get('idUniversity');
      const universityID = parseFloat(this.tmp);

      if (Number.isNaN(universityID) || universityID == 0) {
        this.arrayTeachersUniversities = ARRAY_TEACHERS_UNIVERSITIES;
        this.tmp = 0;
      } else {
        this.arrayTeachersUniversities = ARRAY_TEACHERS_UNIVERSITIES.filter(
          (teacherUniversity) => teacherUniversity.idUniversity.id === universityID
        );
      }
      this.quantityTeachers = this.arrayTeachersUniversities.length;
      this.teacherUniversitySelected = new TeacherUniversity(
        new Teacher(0, '', '', '', ''),
        new University(0, '', '', '')
      );
    });
  }

  public selectTeacherUniversity(objTU: TeacherUniversity): void {
    this.teacherUniversitySelected = objTU;
  }

}
