import { ARRAY_TEACHERS_UNIVERSITIES } from './../../../mocks/teacher-university-mock';
import { Teacher } from 'src/app/models/teacher';
import { University } from 'src/app/models/university';
import { TeacherUniversity } from './../../../models/teacher-university';

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css'],
})
export class DetailComponent implements OnInit {
  public arrayTeachersUniversities: Array<TeacherUniversity>;
  public quantityUniversities: number;
  public teacherUniversitySelected: TeacherUniversity;
  public tmp: any;

  constructor(private route: ActivatedRoute) {
    this.arrayTeachersUniversities = [];
    this.quantityUniversities = 0;
    this.teacherUniversitySelected = new TeacherUniversity (
      new Teacher(0, '', '', '', ''),
      new University(0, '', '', '')
    );
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe((param: ParamMap) => {
      this.tmp = param.get('idTeacher');
      const teacherID = parseFloat(this.tmp);

      if (Number.isNaN(teacherID) || teacherID == 0) {
        this.arrayTeachersUniversities = ARRAY_TEACHERS_UNIVERSITIES;
        this.tmp = 0;
      } else {
        this.arrayTeachersUniversities = ARRAY_TEACHERS_UNIVERSITIES.filter(
          (teacherUniversity) => teacherUniversity.idTeacher.id === teacherID
        );
      }
      this.quantityUniversities = this.arrayTeachersUniversities.length;
      this.teacherUniversitySelected = new TeacherUniversity(
        new Teacher(0, '', '', '', ''),
        new University(0, '', '', '')
      );
    });
  }

  public selectTeacherUniversity(objTU: TeacherUniversity): void {
    this.teacherUniversitySelected = objTU;
  }
}
