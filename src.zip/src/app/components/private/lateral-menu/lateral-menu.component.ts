import { ARRAY_TEACHERS } from 'src/app/mocks/teacher-mock';
import { Teacher } from './../../../models/teacher';

import { ArrayPipe } from './../../../pipes/array.pipe';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-lateral-menu',
  templateUrl: './lateral-menu.component.html',
  styleUrls: ['./lateral-menu.component.css'],
  providers: [ArrayPipe],
})

export class LateralMenuComponent implements OnInit {

  public arrayTeachers: Array<Teacher>;
  public objTeachersSelected: Teacher;

  constructor(private sort: ArrayPipe) {
    this.arrayTeachers = [];
    this.objTeachersSelected = new Teacher(0, '', '', '', '');
  }

  ngOnInit(): void {
    const parameters = ['teacherName', 'ASC'];
    this.arrayTeachers = this.sort.transform(ARRAY_TEACHERS, parameters);
  }

  public selectTeacher(objTeacher: Teacher): void {
    this.objTeachersSelected = objTeacher;
  }

  public initialize(): void {
    const parameters = ['teacherName', 'ASC'];
    this.arrayTeachers = this.sort.transform(ARRAY_TEACHERS, parameters);
    this.objTeachersSelected = new Teacher(0, '', '', '', '');
  }
}
