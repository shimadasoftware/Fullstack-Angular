import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgSelectModule } from '@ng-select/ng-select';

import { FormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { ModalModule } from 'ngx-bootstrap/modal';
import { NgxPaginationModule } from 'ngx-pagination';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AccessComponent } from './components/access/access.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { StartComponent } from './components/start/start.component';
import { UpperMenuComponent } from './components/upper-menu/upper-menu.component';
import { TeachersAdminComponent } from './components/public/teachers-admin/teachers-admin.component';
import { TeachersListComponent } from './components/public/teachers-list/teachers-list.component';
import { TeachersPrincipalComponent } from './components/public/teachers-principal/teachers-principal.component';
import { TeachersCreateComponent } from './components/public/teachers-create/teachers-create.component';
import { TeachersEditComponent } from './components/public/teachers-edit/teachers-edit.component';
import { LateralMenuComponent } from './components/private/lateral-menu/lateral-menu.component';
import { PrincipalComponent } from './components/private/principal/principal.component';
import { DetailComponent } from './components/private/detail/detail.component';
import { ArrayPipe } from './pipes/array.pipe';
import { UniversitiesAdminComponent } from './components/public/universities-admin/universities-admin.component';
import { UniversitiesCreateComponent } from './components/public/universities-create/universities-create.component';
import { UniversitiesEditComponent } from './components/public/universities-edit/universities-edit.component';
import { UniversitiesListComponent } from './components/public/universities-list/universities-list.component';
import { UniversitiesPrincipalComponent } from './components/public/universities-principal/universities-principal.component';
import { ValidateComponent } from './components/validate/validate.component';
import { PrincipalUniversityComponent } from './components/external/principal-university/principal-university.component';
import { LateralMenuUniversityComponent } from './components/external/lateral-menu-university/lateral-menu-university.component';
import { DetailUniversityComponent } from './components/external/detail-university/detail-university.component';

@NgModule({
  declarations: [
    AppComponent,
    AccessComponent,
    NotFoundComponent,
    StartComponent,
    UpperMenuComponent,
    TeachersAdminComponent,
    TeachersListComponent,
    TeachersPrincipalComponent,
    TeachersCreateComponent,
    TeachersEditComponent,
    LateralMenuComponent,
    PrincipalComponent,
    DetailComponent,
    ArrayPipe,
    UniversitiesAdminComponent,
    UniversitiesCreateComponent,
    UniversitiesEditComponent,
    UniversitiesListComponent,
    UniversitiesPrincipalComponent,
    ValidateComponent,
    PrincipalUniversityComponent,
    LateralMenuUniversityComponent,
    DetailUniversityComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ToastrModule.forRoot(),
    ModalModule.forRoot(),
    BrowserAnimationsModule,
    NgxPaginationModule,
    NgSelectModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
