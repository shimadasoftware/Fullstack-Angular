import { University } from './university';
import { Teacher } from './teacher';
export class TeacherUniversity {
  public idTeacher: Teacher;
  public idUniversity: University;

  constructor(idTeac: Teacher, idUni: University) {
    this.idTeacher = idTeac;
    this.idUniversity = idUni;
  }
}
