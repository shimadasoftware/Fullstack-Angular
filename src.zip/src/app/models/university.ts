export class University {
  public id: number;
  public universityName: string;
  public picture: string;
  public pictureBase64: string;

  constructor(id: number, name: string, picture: string, pic64: string) {
    this.id = id;
    this.universityName = name;
    this.picture = picture;
    this.pictureBase64 = pic64;
  }
}
