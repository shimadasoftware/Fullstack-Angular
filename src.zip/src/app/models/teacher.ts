export class Teacher {
    public id: number;
    public document: string;
    public teacherName: string;
    public picture: string;
    public pictureBase64: string;

    public constructor(id: number, doc: string, name: string, pic: string, pic64: string) {
        this.id = id;
        this.document = doc;
        this.teacherName = name;
        this.picture = pic;
        this.pictureBase64 = pic64;
    }
}
