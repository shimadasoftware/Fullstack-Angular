export class Login {
  public id: number;
  public email: string;
  public password: string;

  public constructor(id: number, email: string, password: string) {
      this.id = id;
      this.email = email;
      this.password = password;
  }
}
