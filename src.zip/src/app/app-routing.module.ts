import { ValidateComponent } from './components/validate/validate.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AccessComponent } from './components/access/access.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { TeachersAdminComponent } from './components/public/teachers-admin/teachers-admin.component';
import { TeachersCreateComponent } from './components/public/teachers-create/teachers-create.component';
import { TeachersEditComponent } from './components/public/teachers-edit/teachers-edit.component';
import { TeachersListComponent } from './components/public/teachers-list/teachers-list.component';
import { TeachersPrincipalComponent } from './components/public/teachers-principal/teachers-principal.component';
import { StartComponent } from './components/start/start.component';
import { DetailComponent } from './components/private/detail/detail.component';
import { PrincipalComponent } from './components/private/principal/principal.component';
import { UniversitiesPrincipalComponent } from './components/public/universities-principal/universities-principal.component';
import { UniversitiesListComponent } from './components/public/universities-list/universities-list.component';
import { UniversitiesCreateComponent } from './components/public/universities-create/universities-create.component';
import { UniversitiesEditComponent } from './components/public/universities-edit/universities-edit.component';
import { UniversitiesAdminComponent } from './components/public/universities-admin/universities-admin.component';
import { PrincipalUniversityComponent } from './components/external/principal-university/principal-university.component';
import { DetailUniversityComponent } from './components/external/detail-university/detail-university.component';

const routes: Routes = [
  { path: 'start', component: StartComponent },
  { path: 'access', component: AccessComponent,
    children:[
      { path: 'validate', component: ValidateComponent },
    ],
  },
  { path: 'teachers', component: TeachersPrincipalComponent,
    children:[
      { path: 'list', component: TeachersListComponent },
      { path: 'edit/:idTeacher', component: TeachersEditComponent },
      { path: 'create', component: TeachersCreateComponent },
      { path: 'admin', component: TeachersAdminComponent },
      { path: '', redirectTo: '/start', pathMatch: 'full' },
      { path: '**', component: NotFoundComponent },
    ],
  },
  { path: 'universities', component: UniversitiesPrincipalComponent,
    children:[
      { path: 'list', component: UniversitiesListComponent },
      { path: 'edit/:idUniversity', component: UniversitiesEditComponent },
      { path: 'create', component: UniversitiesCreateComponent },
      { path: 'admin', component: UniversitiesAdminComponent },
      { path: '', redirectTo: '/start', pathMatch: 'full' },
      { path: '**', component: NotFoundComponent },
    ],
  },
  { path: 'private', component: PrincipalComponent,
    children:[
      { path: 'detail', component: DetailComponent },
      { path: 'detail/:idTeacher', component: DetailComponent },
      { path: '', redirectTo: 'detail', pathMatch: 'full' },
      { path: '**', component: NotFoundComponent },
    ],
  },
  { path: 'external', component: PrincipalUniversityComponent,
    children:[
      { path: 'detailUniversity', component: DetailUniversityComponent },
      { path: 'detailUniversity/:idUniversity', component: DetailUniversityComponent },
      { path: '', redirectTo: 'detailUniversity', pathMatch: 'full' },
      { path: '**', component: NotFoundComponent },
    ],
  },
  { path: '', redirectTo: 'start', pathMatch: 'full' },
  { path: '**', component: NotFoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
