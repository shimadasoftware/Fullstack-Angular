import { ARRAY_UNIVERSITIES } from './university-mock';
import { TeacherUniversity } from './../models/teacher-university';
import { ARRAY_TEACHERS } from './teacher-mock';

export const ARRAY_TEACHERS_UNIVERSITIES: Array<TeacherUniversity> = [
  new TeacherUniversity(ARRAY_TEACHERS[0], ARRAY_UNIVERSITIES[0]),
  new TeacherUniversity(ARRAY_TEACHERS[0], ARRAY_UNIVERSITIES[1]),
  new TeacherUniversity(ARRAY_TEACHERS[1], ARRAY_UNIVERSITIES[4]),
  new TeacherUniversity(ARRAY_TEACHERS[1], ARRAY_UNIVERSITIES[5]),
  new TeacherUniversity(ARRAY_TEACHERS[2], ARRAY_UNIVERSITIES[4]),
  new TeacherUniversity(ARRAY_TEACHERS[2], ARRAY_UNIVERSITIES[3]),
  new TeacherUniversity(ARRAY_TEACHERS[3], ARRAY_UNIVERSITIES[5]),
  new TeacherUniversity(ARRAY_TEACHERS[3], ARRAY_UNIVERSITIES[6]),
  new TeacherUniversity(ARRAY_TEACHERS[4], ARRAY_UNIVERSITIES[7]),
  new TeacherUniversity(ARRAY_TEACHERS[4], ARRAY_UNIVERSITIES[8]),
  new TeacherUniversity(ARRAY_TEACHERS[6], ARRAY_UNIVERSITIES[9]),
  new TeacherUniversity(ARRAY_TEACHERS[6], ARRAY_UNIVERSITIES[0]),
  new TeacherUniversity(ARRAY_TEACHERS[7], ARRAY_UNIVERSITIES[4]),
  new TeacherUniversity(ARRAY_TEACHERS[7], ARRAY_UNIVERSITIES[4]),
  new TeacherUniversity(ARRAY_TEACHERS[9], ARRAY_UNIVERSITIES[2]),
  new TeacherUniversity(ARRAY_TEACHERS[10], ARRAY_UNIVERSITIES[2]),
  new TeacherUniversity(ARRAY_TEACHERS[10], ARRAY_UNIVERSITIES[5]),
  new TeacherUniversity(ARRAY_TEACHERS[10], ARRAY_UNIVERSITIES[2]),
  new TeacherUniversity(ARRAY_TEACHERS[11], ARRAY_UNIVERSITIES[7]),
];
